﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Microsoft.Speech.Recognition;
using System.Speech.Synthesis;
using VeronicaAI.Properties;
using System.Globalization;

namespace VeronicaAI
{
    public partial class frmMain : Form
    {
        Random rnd = new Random();
        public static List<string> MsgList = new List<string>();
        public static List<string> MsgLink = new List<string>();
        int count = 1;
        int timer = 11;
        int EmailNum = 0;
        DateTime timenow = DateTime.Now;
        public static String Temperature, Condition, Humidity, WinSpeed, TFCond, TFHigh, TFLow, Town;

        void Default_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            int ranNum;
            string speech = e.Result.Text;
            switch (speech)
            {
                #region Greetings
                case "Hello":
                case "Hello Veronica":
                    timenow = DateTime.Now;
                    if (timenow.Hour >= 5 && timenow.Hour < 12)
                    { Veronica.SpeakAsync("Goodmorning " + Settings.Default.User); }
                    if (timenow.Hour >= 12 && timenow.Hour < 18)
                    { Veronica.SpeakAsync("Good afternoon " + Settings.Default.User); }
                    if (timenow.Hour >= 18 && timenow.Hour < 24)
                    { Veronica.SpeakAsync("Good evening " + Settings.Default.User); }
                    if (timenow.Hour < 5)
                    { Veronica.SpeakAsync("Hello " + Settings.Default.User + ", it's getting late"); }
                    break;

                case "Goodbye":
                case "Goodbye Veronica":
                case "Close Veronica":
                    Veronica.Speak("Farewell");
                    Close();
                    break;

                case "Veronica":
                    ranNum = rnd.Next(1, 5);
                    if (ranNum == 1) { QEvent = ""; Veronica.SpeakAsync("Yes sir"); }
                    else if (ranNum == 2) { QEvent = ""; Veronica.SpeakAsync("Yes?"); }
                    else if (ranNum == 3) { QEvent = ""; Veronica.SpeakAsync("How may I help?"); }
                    else if (ranNum == 4) { QEvent = ""; Veronica.SpeakAsync("How may I be of assistance?"); }
                    break;

                case "What's my name?":
                    Veronica.SpeakAsync(Settings.Default.User);
                    break;

                case "Stop talking":
                    Veronica.SpeakAsyncCancelAll();
                    ranNum = rnd.Next(1, 5);
                    if (ranNum == 5)
                    { Veronica.Speak("fine"); }
                    break;
                #endregion

                #region Condition of the Day
                case "What time is it":
                    timenow = DateTime.Now;
                    string time = timenow.GetDateTimeFormats('t')[0];
                    Veronica.SpeakAsync(time);
                    break;

                case "What day is it":
                    Veronica.SpeakAsync(DateTime.Today.ToString("dddd"));
                    break;

                case "Whats the date":
                case "Whats todays date":
                    Veronica.SpeakAsync(DateTime.Today.ToString("dd-MM-yyyy"));
                    break;

                case "Hows the weather":
                case "Whats the weather like":
                case "Whats it like outside":
                    RSSReader.GetWeather();
                    if (QEvent == "connected")
                    { Veronica.SpeakAsync("The weather in " + Town + " is " + Condition + " at " + Temperature + " degrees. There is a humidity of " + Humidity + " and a windspeed of " + WinSpeed + " miles per hour"); }
                    else if (QEvent == "failed")
                    { Veronica.SpeakAsync("I seem to be having a bit of trouble connecting to the server. Just look out the window"); }
                    break;

                case "What will tomorrow be like":
                case "Whats tomorrows forecast":
                case "Whats tomorrow like":
                    RSSReader.GetWeather();
                    if (QEvent == "connected")
                    { Veronica.SpeakAsync("Tomorrows forecast is " + TFCond + " with a high of " + TFHigh + " and a low of " + TFLow); }
                    else if (QEvent == "failed")
                    { Veronica.SpeakAsync("I could not access the server, are you sure you have the right W O E I D?"); }
                    break;

                case "Whats the temperature":
                case "Whats the temperature outside":
                    RSSReader.GetWeather();
                    if (QEvent == "connected")
                    { Veronica.SpeakAsync(Temperature + " degrees"); }
                    else if (QEvent == "failed")
                    { Veronica.SpeakAsync("I could not connect to the weather service"); }
                    break;
                #endregion

                #region Application Commands
                case "Switch Window":
                    SendKeys.SendWait("%{TAB " + count + "}");
                    count += 1;
                    break;

                case "Close window":
                    SendKeys.SendWait("%{F4}");
                    break;

                case "Out of the way":
                    if (WindowState == FormWindowState.Normal)
                    {
                        WindowState = FormWindowState.Minimized;
                        Veronica.SpeakAsync("My apologies");
                    }
                    break;

                case "Come back":
                    if (WindowState == FormWindowState.Minimized)
                    {
                        Veronica.SpeakAsync("Alright");
                        WindowState = FormWindowState.Normal;
                    }
                    break;

                case "Show default commands":
                    string[] defaultcommands = (File.ReadAllLines(@"Default Commands.txt"));
                    Veronica.SpeakAsync("Very well");
                    lstCommands.Items.Clear();
                    lstCommands.SelectionMode = SelectionMode.None;
                    lstCommands.Visible = true;
                    foreach (string command in defaultcommands)
                    {
                        lstCommands.Items.Add(command);
                    }
                    break;

                case "Show shell commands":
                    Veronica.SpeakAsync("Here we are");
                    lstCommands.Items.Clear();
                    lstCommands.SelectionMode = SelectionMode.None;
                    lstCommands.Visible = true;
                    foreach (string command in ArrayShellCommands)
                    {
                        lstCommands.Items.Add(command);
                    }
                    break;

                case "Show social commands":
                    Veronica.SpeakAsync("Alright");
                    lstCommands.Items.Clear();
                    lstCommands.SelectionMode = SelectionMode.None;
                    lstCommands.Visible = true;
                    foreach (string command in ArraySocialCommands)
                    {
                        lstCommands.Items.Add(command);
                    }
                    break;

                case "Show web commands":
                    Veronica.SpeakAsync("Ok");
                    lstCommands.Items.Clear();
                    lstCommands.SelectionMode = SelectionMode.None;
                    lstCommands.Visible = true;
                    foreach (string command in ArrayWebCommands)
                    {
                        lstCommands.Items.Add(command);
                    }
                    break;
                case "Show Music Library":
                    lstCommands.SelectionMode = SelectionMode.One;
                    lstCommands.Items.Clear();
                    lstCommands.Visible = true;
                    Veronica.SpeakAsync("OK");
                    i = 0;
                    foreach (string file in MyMusicPaths)
                    {
                        lstCommands.Items.Add(MyMusicNames[i]);
                        i += 1;
                    }
                    QEvent = "Play music file";
                    break;

                case "Show Video Library":
                    lstCommands.SelectionMode = SelectionMode.One;
                    lstCommands.Items.Clear();
                    lstCommands.Visible = true;
                    i = 0;
                    foreach (string file in MyVideoPaths)
                    {
                        if (file.Contains(".mp4") || file.Contains(".avi") || file.Contains(".mkv"))
                        { lstCommands.Items.Add(MyVideoNames[i]); i += 1; }
                        else { i += 1; }
                    }
                    QEvent = "Play video file";
                    break;

                case "Show Email List":
                    lstCommands.SelectionMode = SelectionMode.One;
                    lstCommands.Items.Clear();
                    lstCommands.Visible = true;
                    foreach (string line in MsgList)
                    {
                        lstCommands.Items.Add(line);
                    }
                    QEvent = "Checkfornewemails";
                    break;

                case "Show listbox":
                    lstCommands.Visible = true;
                    break;

                case "Hide listbox":
                    lstCommands.Visible = false;
                    break;
                #endregion

                #region Shutdown / Restart / Logoff
                case "Shutdown":
                    if (ShutdownTimer.Enabled == false)
                    {
                        QEvent = "shutdown";
                        Veronica.SpeakAsync("Are you sure you want to " + QEvent + "?");
                    }
                    break;

                case "Log off":
                    if (ShutdownTimer.Enabled == false)
                    {
                        QEvent = "logoff";
                        Veronica.SpeakAsync("Are you sure you want to " + QEvent + "?");
                    }
                    break;

                case "Restart":
                    if (ShutdownTimer.Enabled == false)
                    {
                        QEvent = "restart";
                        Veronica.SpeakAsync("Are you sure you want to " + QEvent + "?");
                    }
                    break;

                case "Abort":
                    if (ShutdownTimer.Enabled == true)
                    {
                        timer = 11;
                        lblTimer.Text = timer.ToString();
                        ShutdownTimer.Enabled = false;
                        lblTimer.Visible = false;
                    }
                    break;
                #endregion                    
            }
        }
        void startlistening_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            string speech = e.Result.Text;
            switch (speech)
            {
                case "Veronica":
                    startlistening.RecognizeAsyncCancel();
                    Veronica.SpeakAsync("Yes?");
                    _recognizer.RecognizeAsync(RecognizeMode.Multiple);
                    break;
            }
        }
    }
}