﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Globalization;
using System.Threading;
using VeronicaAI.Properties;
using Microsoft.Speech.Recognition;
using System.Speech.Synthesis;

namespace VeronicaAI
{
    public partial class frmMain : Form
    {
        SpeechRecognitionEngine _recognizer = new SpeechRecognitionEngine(); //Creates the Speech Recognition Engine and sets the default language to English-US dialect
        SpeechRecognitionEngine startlistening = new SpeechRecognitionEngine();
        public static SpeechSynthesizer Veronica = new SpeechSynthesizer(); //Creates the speech synthesizer to allow the program to respond
        
        Grammar commandsGrammer;//Grammar variables allow us to load and unload words into VeronicaAI's vocabulary and update them during runtime without the need to restart the program

        String[] ArrayCommandsRequest;
        String[] ArrayCommandsResponse;
        String[] ArrayCommandsAction;

        public static string cmdReqPath; //These strings will be used to refer to the Command request text document
        public static string cmdResPath; //These strings will be used to refer to the Command Response text document
        public static string cmdActPth; //These strings will be used to refer to the Command Action text document

        public static String userName = Environment.UserName; //This variable stores the name of your computer so we can refer to specific file locations or assume your name

        public static String QEvent; //This variable is used periodically to determine which event we are trying to achieve when there are multiple possible outcomes
        int i = 0; //This integer variable will be used for loops and referring to specific elements in arrays
        int recTimeOut = 0;
        StreamWriter sw; //Sets a variable that allows us to read and write to text documents
        ComboBox cmbxLang;

        public frmMain()
        {
            InitializeComponent();
            Settings.Default.Language = "en-US";
            if (Settings.Default.Language == String.Empty)
            {
                //AskForACountry();
                Veronica.SpeakAsyncCancelAll();
            }

            try
            {
                Thread.CurrentThread.CurrentCulture = new CultureInfo(Settings.Default.Language);
                Thread.CurrentThread.CurrentUICulture = new CultureInfo(Settings.Default.Language);
                _recognizer = new SpeechRecognitionEngine(new CultureInfo(Settings.Default.Language));
                startlistening = new SpeechRecognitionEngine(new CultureInfo(Settings.Default.Language));
                Veronica.SelectVoiceByHints(VoiceGender.Female, VoiceAge.Teen);
            }
            catch (Exception ex)
            {
                ErrorLog(ex.ToString());
                //AskForACountry();
            }


            //lblLanguage.Text = Settings.Default.Language;

            if (Settings.Default.User.ToString() == String.Empty) //Checks for user info. If none is available it sets to default
            {
                Settings.Default.User = userName; Settings.Default.Save();
            }
            Veronica.SpeakAsync("It is nice to make your acquaintance " + Settings.Default.User + ", my name is Veronica and I will be your personal digital assistant");

            Directory.CreateDirectory(@"C:\Users\" + userName + "\\Documents\\Veronica Commands"); //We create 'Jarvis Custom Commands' folder in the My Documents folder so we have a place to store our text documents
            Settings.Default.Request = @"C:\Users\" + userName + "\\Documents\\Veronica Commands\\CommandsReq.txt"; //We save the text document file locations into our settings even before they've been created so we can refer to them easily and globally
            Settings.Default.Response = @"C:\Users\" + userName + "\\Documents\\Veronica Commands\\CommandsRes.txt";
            Settings.Default.Action = @"C:\Users\" + userName + "\\Documents\\Veronica Commands\\CommandsAct.txt";
            Settings.Default.Save();            

            cmdReqPath = Settings.Default.Request;
            cmdResPath = Settings.Default.Response;
            cmdActPth = Settings.Default.Action;

            //string[] defaultcommands = (File.ReadAllLines(@"Default Commands.txt")); //Loading all default commands into an array
            //foreach (string command in defaultcommands)
            //{
            //    lstCommands.Items.Add(command); //We load them into the listbox on start up just in case someone forgets the commands and they can say, "Show listbox"
            //}
            
            if (!File.Exists(cmdReqPath)) //This is used to create the Custom Command text documents if they don't already exist and write in default commands so we don't encounter any errors. These text documents should always have at least one valid line in them
            {
                sw = File.CreateText(cmdReqPath);
                sw.Write("My Documents");
                sw.Close();
            }

            if (!File.Exists(cmdResPath))
            {
                sw = File.CreateText(cmdResPath);
                sw.Write("Right away");
                sw.Close();
            }

            if (!File.Exists(cmdActPth))
            {
                sw = File.CreateText(cmdActPth);
                sw.Write(@"C:\Users\" + userName + "\\Documents");
                sw.Close();
            }
            
            ArrayCommandsRequest = File.ReadAllLines(cmdReqPath); //This loads all written commands in our Custom Commands text documents into arrays so they can be loaded into our grammars
            ArrayCommandsResponse = File.ReadAllLines(cmdResPath);
            ArrayCommandsAction = File.ReadAllLines(cmdActPth);

            try
            {
                commandsGrammer = new Grammar(new GrammarBuilder(new Choices(ArrayCommandsRequest)));
                _recognizer.LoadGrammarAsync(commandsGrammer);
            }
            catch
            {
                Veronica.SpeakAsync("I've detected an invalid entry in your commands, possibly a blank line. commands will cease to work until it is fixed.");
            }

            _recognizer.SetInputToDefaultAudioDevice(); //Sets Mic input to the default Mic
            Choices chVolume = new Choices();

            for (int inNum = 0; inNum <= 100; inNum++)
            {
                chVolume.Add(Convert.ToString("Set the volume at " + inNum + " percent"));
            }

            _recognizer.LoadGrammarAsync(new Grammar(new GrammarBuilder(chVolume)));
            _recognizer.LoadGrammarAsync(new Grammar(new GrammarBuilder(new Choices(File.ReadAllLines(@"Default Commands.txt"))))); //Load our Default Commands text document so we have commands to start with
            _recognizer.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(commands_SpeechRecognized); //These are event handlers that are responsible for carrying out all necessary tasks if a speech event is recognized

            _recognizer.AudioLevelUpdated += new EventHandler<AudioLevelUpdatedEventArgs>(_recognizer_AudioLevelUpdated);
            _recognizer.SpeechDetected += new EventHandler<SpeechDetectedEventArgs>(_recognizer_SpeechDetected);

            startlistening.SetInputToDefaultAudioDevice();
            startlistening.LoadGrammarAsync(new Grammar(new GrammarBuilder(new Choices("Veronica")))); //Loads a grammar choice into the speech recognition engine
            startlistening.SpeechRecognized += new EventHandler<SpeechRecognizedEventArgs>(startlistening_SpeechRecognized); //The event handler that allows us to say "JARVIS Come Back Online". Only one Speech Recognition Engine is active at a time.

            Veronica.SpeakProgress += new EventHandler<SpeakProgressEventArgs>(VERONICA_SpeakProgress);
            Veronica.SpeakCompleted += new EventHandler<SpeakCompletedEventArgs>(VERONICA_SpeakCompleted);
            
            //string tmppath = System.IO.Path.GetTempFileName();
            //tmppath = tmppath.Replace(".tmp", ".mp4");
            //Stream tmp = System.IO.File.Create(tmppath);
            //tmp.Write(Resources.Produce, 0, Resources.Produce.Length);
            //tmp.Close();
            //axWindowsMediaPlayer1.URL = tmppath;
            //axWindowsMediaPlayer1.Size = new System.Drawing.Size(447, 282);
            //axWindowsMediaPlayer1.Location = new Point(0, 0);
            //axWindowsMediaPlayer1.Visible = true;
            //axWindowsMediaPlayer1.Ctlcontrols.play();

            //if (Settings.Default.User.ToString() == String.Empty) //Checks for user info. If none is available it sets to default
            //{ Settings.Default.User = userName; Settings.Default.Save(); Jarvis.SpeakAsync("It is nice to make your acquaintance " + Settings.Default.User + ", my name is JARVIS and I will be your personal digital assistant"); }
            //else
            //{
            //    RSSReader.GetWeather();
            //    if (QEvent == "connected")
            //    { Jarvis.SpeakAsync("It is good to see you again " + Settings.Default.User + ". The time is " + timenow.GetDateTimeFormats('t')[0] + " and the weather in " + Town + " is " + Condition + " at " + Temperature + " degrees. How can I help?"); }
            //    else if (QEvent == "failed")
            //    { Jarvis.SpeakAsync("It is good to see you again " + Settings.Default.User + ". It is currently " + timenow.GetDateTimeFormats('t')[0] + ". What is it you would like me to do first?"); }
            //}

            QEvent = "FormLoad";
            //this.DragDrop += new DragEventHandler(frmMain_DragDrop);
            //this.DragEnter += new DragEventHandler(frmMain_DragEnter);
        }

        #region Recognizer Settings
        void _recognizer_SpeechDetected(object sender, SpeechDetectedEventArgs e)
        {
            recTimeOut = 0;
        }

        void _recognizer_AudioLevelUpdated(object sender, AudioLevelUpdatedEventArgs e)
        {
            //pbMicrophoneLevel.Value = e.AudioLevel;
        }

        private void tmrSpeech_Tick(object sender, EventArgs e)
        {
            if (recTimeOut == 10)
            {
                _recognizer.RecognizeAsyncCancel();
            }
            else if (recTimeOut == 11)
            {
                startlistening.RecognizeAsync(RecognizeMode.Multiple);
                //tmrSpeech.Stop();
                recTimeOut = 0;
            }
            recTimeOut += 1;
        }
        #endregion

        #region Speaking Animation
        void VERONICA_SpeakCompleted(object sender, SpeakCompletedEventArgs e)
        {
            //pictureBox1.Image = Properties.Resources.NotSpeaking;
        }

        string word;
        int SpeakCount;
        void VERONICA_SpeakProgress(object sender, SpeakProgressEventArgs e)
        {
            word = e.Text.ToLower();
            SpeakCount = 0;
            //tmrBgPic.Enabled = true;
        }

        private void tmrBgPic_Tick(object sender, EventArgs e)
        {
            if (word[SpeakCount] == 'a' || word[SpeakCount] == 'e' || word[SpeakCount] == 'i' || word[SpeakCount] == 'o' || word[SpeakCount] == 'u')
            {
                //pictureBox1.Image = Properties.Resources.Vowel;
            }
            else
            {
                //pictureBox1.Image = Properties.Resources.Consonant;
            }
            if (SpeakCount == word.Length - 1)
            { SpeakCount = 0;
                //tmrBgPic.Enabled = false;
                //pictureBox1.Image = Properties.Resources.NotSpeaking;
            }

            SpeakCount += 1;
        }
        #endregion


        #region Speech recognized
        void commands_SpeechRecognized(object sender, SpeechRecognizedEventArgs e)
        {
            //tmrSpeech.Start();
            string speech = e.Result.Text; //Sets the SpeechRecognized event variable to a string variable called speech
            i = 0; //Ensures "i" is = to 0 so we can start our loop from the beginning of our arrays
            try
            {
                foreach (string line in ArrayCommandsRequest)
                {
                    if (line == speech) //If line == speech it will open the corresponding program/file
                    {
                        //System.Diagnostics.Process.Start(ArrayShellLocation[i]); //Opens the program/file of the same elemental position as the ArrayShellCommands command that was equal to speech
                        Veronica.SpeakAsync(ArrayCommandsAction[i]); //Gives the response of the same elemental position as the ArrayShellCommands command that was equal to speech
                    }
                    i += 1; //if the line in ArrayShellCommands does not equal speech it will add 1 to "i" and go through the loop until it finds a match between the line and spoken event
                }
            }
            catch
            {
                i += 1;
                Veronica.SpeakAsync("Im sorry it appears the command " + speech + " on line " + i + " is accompanied by either a blank line or an incorrect file location");
            }
        }
        #endregion

        public void ErrorLog(string error)
        {
            MessageBox.Show(error);
            string DTL = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            using (System.IO.StreamWriter sw = System.IO.File.AppendText(DTL + "\\Error Report.txt"))
            {
                sw.WriteLine("~~~" + DateTime.Now + "~~~");
                sw.WriteLine(error.ToString());
                sw.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~");
                sw.WriteLine("");
                sw.Close();

            }
        }

        public void ErrorReport(string error)
        {
            string DTL = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            using (System.IO.StreamWriter sw = System.IO.File.AppendText(DTL + "\\Error Report.txt"))
            {
                sw.WriteLine("~~~" + DateTime.Now + "~~~");
                sw.WriteLine(error.ToString());
                sw.WriteLine("~~~~~~~~~~~~~~~~~~~~~~~~~");
                sw.WriteLine("");
                sw.Close();

            }
        }
    }
}