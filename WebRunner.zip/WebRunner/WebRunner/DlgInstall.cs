using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace WebRunner
{
    public partial class DlgInstall : Form
    {
        public DlgInstall()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            textBox1.Visible = !textBox1.Visible;
            linkLabel1.Text = ((textBox1.Visible) ? "Hide Detail" : "Show Detail");            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            progressBar1.Maximum = 6;
            progressBar1.Value = 0;
            textBox1.Clear();
            string s = Environment.GetEnvironmentVariable("windir");
            textBox1.Text += "Check for Exist %system_root%\\assembly\\GAC_32\r\n";
            if (!Directory.Exists(s + "\\assembly\\GAC_32"))
            {
                Directory.CreateDirectory(s + "\\assembly\\GAC_32");
                textBox1.Text += "Create Directory %system_root%\\assembly\\GAC_32\r\n";
            }
            else
                textBox1.Text += "OK\r\n";
            progressBar1.Value++;
            textBox1.Text += "Check Exist 'WebDev.WebHost' Directory\r\n";
            if (!Directory.Exists(s + "\\assembly\\GAC_32\\WebDev.WebHost"))
            {
                Directory.CreateDirectory(s + "\\assembly\\GAC_32\\WebDev.WebHost");
                textBox1.Text += "Create Directory %system_root%\\assembly\\GAC_32\\WebDev.WebHost\r\n";
            }
            else
                textBox1.Text += "OK\r\n";
            progressBar1.Value++;
            //8.0.0.0__b03f5f7f11d50a3a
            textBox1.Text += "Check Exist '8.0.0.0__b03f5f7f11d50a3a' Directory\r\n";
            if (!Directory.Exists(s + "\\assembly\\GAC_32\\WebDev.WebHost\\8.0.0.0__b03f5f7f11d50a3a"))
            {
                Directory.CreateDirectory(s + "\\assembly\\GAC_32\\WebDev.WebHost\\8.0.0.0__b03f5f7f11d50a3a");
                textBox1.Text += "Create Directory %system_root%\\assembly\\GAC_32\\WebDev.WebHost\\8.0.0.0__b03f5f7f11d50a3a\r\n";
            }
            else
                textBox1.Text += "OK\r\n";
            progressBar1.Value++;
            textBox1.Text += "Check Exist 'WebDev.WebHost.dll' File\r\n";
            if (!File.Exists(s + "\\assembly\\GAC_32\\WebDev.WebHost\\8.0.0.0__b03f5f7f11d50a3a\\WebDev.WebHost.dll"))
            {
                string s1 = AppDomain.CurrentDomain.BaseDirectory + "WebDev.WebHost.dll";
                File.Copy(s1, s + "\\assembly\\GAC_32\\WebDev.WebHost\\8.0.0.0__b03f5f7f11d50a3a\\WebDev.WebHost.dll");
                textBox1.Text += "Copy File WebDev.WebHost.dll\r\n";
            }
            else
                textBox1.Text += "OK\r\n";
            progressBar1.Value++;
            textBox1.Text += "Check Exist 'WebDev.WebServer.EXE' File\r\n";
            if (!File.Exists(s + "\\Microsoft.NET\\Framework\\v2.0.50727\\WebDev.WebServer.EXE"))
            {
                string s1 = AppDomain.CurrentDomain.BaseDirectory + "WebDev.WebServer.EXE";
                File.Copy(s1, s + "\\Microsoft.NET\\Framework\\v2.0.50727\\WebDev.WebServer.EXE");
                textBox1.Text += "Copy File WebDev.WebServer.EXE\r\n";
            }
            else
                textBox1.Text += "OK\r\n";
            progressBar1.Value++;
            textBox1.Text += "Check Exist 'WebDev.WebServer.exe.manifest' File\r\n";
            if (!File.Exists(s + "\\Microsoft.NET\\Framework\\v2.0.50727\\WebDev.WebServer.exe.manifest"))
            {
                string s1 = AppDomain.CurrentDomain.BaseDirectory + "WebDev.WebServer.exe.manifest";
                File.Copy(s1, s + "\\Microsoft.NET\\Framework\\v2.0.50727\\WebDev.WebServer.exe.manifest");
                textBox1.Text += "Copy File WebDev.WebServer.exe.manifest\r\n";
            }
            else
                textBox1.Text += "OK\r\n";
            progressBar1.Value++;
        }
    }
}