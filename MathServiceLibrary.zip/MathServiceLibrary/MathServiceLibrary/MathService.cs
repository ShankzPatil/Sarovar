﻿namespace MathServiceLibrary
{
    public class MathService:IMathService
    {

        public int Add(int num1, int num2)
        {
            return num1 + num2;
        }

        public int Subtract(int num1, int num2)
        {
            int result = 0;
            if (num1 > num2)
            {
                result = num1 - num2;
            }
            else
            {
                result = num2 - num1;
            }
            return result;
        }

        public int Multiply(int num1, int num2)
        {
            return (num1 * num2);
        }
    }
}
