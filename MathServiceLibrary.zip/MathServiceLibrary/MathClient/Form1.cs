﻿using System;
using System.Windows.Forms;

namespace MathClient
{
    public partial class Form1 : Form
    {
        MathServiceClient myClient = new MathServiceClient();
        public Form1()
        {
            InitializeComponent();

           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            
            int firstNumber = Convert.ToInt32(txtFirstNumber.Text);
            int secondNumber = Convert.ToInt32(txtSecondNumber.Text);

            int result = myClient.Add(firstNumber, secondNumber);
            txtResult.Text = result.ToString() ;
        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            int firstNumber = Convert.ToInt32(txtFirstNumber.Text);
            int secondNumber = Convert.ToInt32(txtSecondNumber.Text);

            int result = myClient.Subtract(firstNumber, secondNumber);
            txtResult.Text = result.ToString();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            int firstNumber = Convert.ToInt32(txtFirstNumber.Text);
            int secondNumber = Convert.ToInt32(txtSecondNumber.Text);

            int result = myClient.Multiply(firstNumber, secondNumber);
            txtResult.Text = result.ToString();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtFirstNumber.Text = "";
            txtSecondNumber.Text = "";
            txtResult.Text = "";
        }
    }
}
